document.addEventListener('DOMContentLoaded', () => {
  const ipElement = document.getElementById('ip');
  const cityElement = document.getElementById('city');
  const stateElement = document.getElementById('state');
  const countryElement = document.getElementById('country');
  const settingsIcon = document.getElementById('settingsIcon');
  const infoDiv = document.getElementById('info');
  const settingsDiv = document.getElementById('settings');
  const backButton = document.getElementById('backButton');
  const badgeColorInput = document.getElementById('badgeColor');
  const saveButton = document.getElementById('save');

  // Load data from storage
  chrome.storage.sync.get(['ip', 'countryName', 'state', 'city'], (data) => {
    ipElement.textContent = data.ip || 'N/A';
    countryElement.textContent = data.countryName || 'N/A';
    stateElement.textContent = data.state || 'N/A';
    cityElement.textContent = data.city || 'N/A';
  });

  // Open settings
  settingsIcon.addEventListener('click', () => {
    infoDiv.style.display = 'none';
    settingsDiv.style.display = 'block';

    // Load saved color on settings load
    chrome.storage.sync.get('badgeColor', ({ badgeColor }) => {
      badgeColorInput.value = badgeColor || '#4688F1';
    });
  });

  // Back button functionality
  backButton.addEventListener('click', () => {
    settingsDiv.style.display = 'none';
    infoDiv.style.display = 'block';
  });

  // Save color on button click
  saveButton.addEventListener('click', () => {
    const badgeColor = badgeColorInput.value;
    chrome.storage.sync.set({ badgeColor }, () => {
      console.log('The color of the icon is preserved:', badgeColor);
      // Update badge color immediately
      chrome.action.setBadgeBackgroundColor({ color: badgeColor });
    });
  });
});
