document.addEventListener('DOMContentLoaded', () => {
  const badgeColorInput = document.getElementById('badgeColor');
  const saveButton = document.getElementById('save');
  const backButton = document.getElementById('backButton');

  // Load saved color on page load
  chrome.storage.sync.get('badgeColor', ({ badgeColor }) => {
    badgeColorInput.value = badgeColor || '#4688F1';
  });

  // Save color on button click
  saveButton.addEventListener('click', () => {
    const badgeColor = badgeColorInput.value;
    chrome.storage.sync.set({ badgeColor }, () => {
      console.log('The color of the icon is preserved:', badgeColor);
      // Update badge color immediately
      chrome.action.setBadgeBackgroundColor({ color: badgeColor });
    });
  });

  // Back button functionality
  backButton.addEventListener('click', () => {
    window.close();
  });
});
