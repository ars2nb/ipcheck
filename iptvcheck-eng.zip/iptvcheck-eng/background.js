chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('fetchIPAndCountry', { periodInMinutes: 1 / 60 }); // 1 minute divided by 60 = ~1 second
  chrome.storage.sync.set({ badgeColor: '#4688F1' }); // Default badge color
  // Apply the default badge color on installation
  chrome.action.setBadgeBackgroundColor({ color: '#4688F1' });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetchIPAndCountry') {
    fetchIPAndCountry();
  }
});

function fetchIPAndCountry() {
  fetch('https://freeipapi.com/api/json')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      const ip = data.ipAddress || 'N/A';
      const country = data.countryName || 'N/A';
      const countryCode = data.countryCode || 'N/A';

      // Setting badge text as country code
      chrome.action.setBadgeText({ text: countryCode });

      // Update storage with country name and other details
      chrome.storage.sync.set({
        countryName: country,
        ip: ip,
        state: data.regionName || 'N/A',
        city: data.cityName || 'N/A'
      }, () => {
        console.log('Data saved:', { country, ip, state: data.regionName, city: data.cityName });
      });

      // Apply the badge color from storage
      chrome.storage.sync.get('badgeColor', ({ badgeColor }) => {
        chrome.action.setBadgeBackgroundColor({ color: badgeColor });
      });
    })
    .catch(error => {
      console.error('Error retrieving IP or country information:', error);
    });
}
